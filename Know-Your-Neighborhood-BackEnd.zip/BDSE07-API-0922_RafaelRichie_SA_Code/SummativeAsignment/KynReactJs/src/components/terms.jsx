import { Container, Row } from "react-bootstrap";
import img from '../img/terms.png';
function Terms(){
    return(
        <Container >
<Row>
    <div className="d-flex my-4">
    <div className="col-12">
      <h1 className="display-3">Terms and Conditions</h1>
      <hr />
      <p className="lead">Welcome to our website. If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern our relationship with you.</p>

      <h4>1. General</h4>
      <p>
        The content of this website is for general information and use only. It is subject to change without notice. Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services, or information available through this website meet your specific requirements.
      </p>

      <h4>2. Intellectual Property</h4>
      <p>
        This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance, and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.
      </p>

      <h4>3. Unauthorized Use</h4>
      <p>
        Unauthorized use of this website may give rise to a claim for damages and/or be a criminal offense.
      </p>

      <h4>4. Links to Other Websites</h4>
      <p>
        This website may include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).
      </p>

      <h4>5. Privacy Policy</h4>
      <p>
        Your use of this website is also subject to our privacy policy. Please review our Privacy Policy, which governs the manner in which we collect, use, disclose, and store your personal information.
      </p>

      <h4>6. Governing Law</h4>
      <p>
        Your use of this website and any dispute arising out of such use of the website is subject to the laws of [your country/region].
      </p>

      <p>By using this website, you signify your acceptance of these terms and conditions. If you do not agree to these terms and conditions, please do not use our website.</p>
    </div>
    </div>
</Row>
        </Container>
    )
}

export default Terms;