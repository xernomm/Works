import React from 'react';
import { Navbar, Nav, NavDropdown, Container, Form, Button } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';
import img from '../img/logo.png'
import LogoutButton from './FacebookLogout';

function Header({ activePage }) {
  let User = sessionStorage.getItem("user");
  User = JSON.parse(User);

  return (
    <Navbar collapseOnSelect expand="lg" bg="light" variant="light">
      <Container>
        <Navbar.Brand href="/">
          <span>
            <img style={{ height: "95px", width: "200px", marginRight: "10px" }} src={img} alt="logo" />
          </span> 
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <NavLink exact to="/" className={`nav-link ${activePage === 'home' ? 'active' : ''}`}>Home</NavLink>
            <NavLink to="/about-us" className={`nav-link ${activePage === 'about-us' ? 'active' : ''}`}>About</NavLink>
            <NavLink to="/contact-us" className={`nav-link ${activePage === 'contact' ? 'active' : ''}`}>Contact</NavLink>

            {!User && (
            <NavDropdown title="Account" id="collasible-nav-dropdown">
            <NavDropdown.Item href="/login">Sign in</NavDropdown.Item>
              <NavDropdown.Item href="/register">Sign Up</NavDropdown.Item>
            </NavDropdown>
              )}

            {User && (
              
                 
            <NavDropdown title="Account" id="collasible-nav-dropdown">
              <NavDropdown.Item href="#">My Profile</NavDropdown.Item>
              <NavDropdown.Item href="#">Settings</NavDropdown.Item>
              <LogoutButton />
            </NavDropdown>
              
           
              )}

          </Nav>
          <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-secondary">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;
