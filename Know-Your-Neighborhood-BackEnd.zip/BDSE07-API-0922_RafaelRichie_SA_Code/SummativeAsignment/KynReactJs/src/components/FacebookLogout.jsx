import { FacebookLoginClient } from "@greatsumini/react-facebook-login";
import { Navbar, Nav, NavDropdown, Container, Form, Button } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';

function LogoutButton(props) {
  const logout = () => {
    FacebookLoginClient.logout(() => {
      sessionStorage.clear();
      window.localStorage.clear();
      alert('Logout Successfull')
      window.location.href = "/";
    });
  };

  return(
    <NavDropdown.Item onClick={() => logout()}>Sign Out</NavDropdown.Item>

  ) 
}

export default LogoutButton;
