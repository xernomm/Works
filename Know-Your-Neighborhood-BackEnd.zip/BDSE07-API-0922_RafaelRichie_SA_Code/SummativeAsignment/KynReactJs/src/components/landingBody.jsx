import React from 'react';
import { Container, Row, Col, Carousel, Button, Form} from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faGoogle, faInstagram, faLinkedin, faGithub, faGem } from '@fortawesome/free-brands-svg-icons';
import { faHome, faEnvelope, faPhone, faPrint } from '@fortawesome/free-solid-svg-icons';
import kyn from '../img/kyn.jpg'
import str from '../img/stores.jpg'
import you from '../img/you.jpg'
import ButtonAndForm from './buttonAndForm';


function LandingBody(){

  let User = sessionStorage.getItem("user");
  User = JSON.parse(User);

  return(
      
<Container fluid>
<Row>
  <div className="jumbobackg col-12">
    <div className="jumboblur">
      <div className="d-flex">
      <Col xs={12} lg={4} md={4} className="mx-auto my-auto px-5">
<div>
        <h1 className="display-2">
        Know Your Neighborhood
        </h1>
            <hr />
        <h3 className="lead">
        More Than Just a Neighborhood
        </h3>
    </div>

</Col>
{User && (

<Col xs={12} lg={5} md={5} className="mx-auto my-auto px-5">
<Button href='' variant='primary' id='getStart' className=' col-12'>Start Exploring</Button>
<Button href='' variant='outline-secondary' id='getStart' className='mt-3 col-12'>My Store</Button>
</Col>
)}
{!User && (
<ButtonAndForm />
)}

      </div>

    </div>
  
  </div>

  </Row>




<Row>

  <div className="d-flex col-12">
  <Carousel className='col-6 my-5 me-5'>
      <Carousel.Item>
        <img
          className="d-block w-100 rounded-5"
          src={kyn}
          alt="First slide"
        />
        <Carousel.Caption>
          <div className="backBlurCarousel col-12">
          <h3>Hang Around</h3>
          <p>Get to know what's around you</p>
          </div>
          
        </Carousel.Caption>
      </Carousel.Item>

      <Carousel.Item>
        <img
          className="d-block w-100 rounded-5"
          src={str}
          alt="Second slide"
        />

        <Carousel.Caption>
          <h3>Visit Stores</h3>
          <p>1000+ Stores are waitinng for you to visit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100 rounded-5"
          src={you}
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3>Let Yourself Be Known</h3>
          <p>
            Introduce and let yourself be known around the neighborhood!
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    <div className='col-4 ms-5 my-auto'>
        <h1 className="display-2">
        Explore Your Neighborhood
        </h1>
            <hr />
            <p className="lead">
              Let Yourself Be Known Around!
            </p>
            <Button href='register' variant="primary" className=" col-8 mt-2">Add Your Shop Now</Button>

    </div>
  </div>

</Row>
    </Container>
    )
}

export default LandingBody;