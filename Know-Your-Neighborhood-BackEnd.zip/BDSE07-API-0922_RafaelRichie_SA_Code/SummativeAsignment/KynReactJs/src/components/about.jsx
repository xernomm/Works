import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

function About(){
    return(
        <div className="mainBack">
            <div className="backBlur">
            <Container>
        <Row>
          <Col className="col-10 mx-auto">
            <h2>About Us</h2>
            <hr />
            <p>
            Welcome to Know Your Neighbourhood, your go-to platform for discovering and exploring your local community. Our mission is to connect you with the people, places, and events that make your neighbourhood unique and vibrant. <br />

At Know Your Neighbourhood, we believe that building strong community connections is essential for a thriving and inclusive society. Whether you're a long-time resident or new to the area, our platform empowers you to discover hidden gems, connect with local businesses, and engage with fellow community members. <br />

We provide a wealth of information about your neighbourhood, including local businesses, parks, schools, events, and much more. Through our interactive maps, curated recommendations, and user-generated content, you'll gain valuable insights into the heartbeat of your community. <br />

Join our growing community of passionate individuals who share a love for their neighbourhoods. Together, let's celebrate the diversity, culture, and spirit that make our communities truly special. <br />

Start exploring your neighbourhood today and unlock a world of local wonders with Know Your Neighbourhood!"
            </p>
            <br />
            <br />
            <h2>Videos</h2>
            <hr />
            <iframe
              className="col-12 my-4"
              height="500"
              src="https://www.youtube.com/embed/QN6IUc3lmtI"
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            ></iframe>
            <br />
            <iframe
              className="col-12 my-4"
              height="500"
              src="https://www.youtube.com/embed/OdU_emI6KrE"
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            ></iframe>
            <p className="mt-5">
              More Videos of Us in{' '}
              <span>
                <a href="https://www.youtube.com/channel/UCjxtDmt1jWpc76kkZBvkvMg">Here</a>
              </span>
            </p>
          </Col>
        </Row>
      </Container>
            </div>
      
    </div>
    )
}

export default About;