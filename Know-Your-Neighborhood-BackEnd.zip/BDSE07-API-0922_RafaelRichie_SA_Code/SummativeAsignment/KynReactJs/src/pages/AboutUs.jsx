import Header from "../components/Header";
import About from "../components/about";

function Aboutss(){
    return (
<>
    <Header activePage={'about-us'} />
    <About />
    </>
    )
    
}

export default Aboutss;