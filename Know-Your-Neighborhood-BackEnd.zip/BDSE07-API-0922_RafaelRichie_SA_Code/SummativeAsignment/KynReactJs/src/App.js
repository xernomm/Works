import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import Footer from './components/Footer';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Registration from './pages/Registration';
import Aboutss from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import TermsAndConditions from './pages/TermsAndConditions';
import RegisterSuccess from './pages/RegisSuccess';


function App() {
  return (
    <>
    
    <div className='mainBack'>
      <div className='backBlur'>
        
      <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/home" element={<Login />} />
        <Route path="/login" element={<RegisterSuccess />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/about-us" element={<Aboutss />} />
        <Route path="/contact-us" element={<ContactUs />} />
        <Route path="/terms" element={<TermsAndConditions />} />

      </Routes>
    </Router>
    </div>
    </div>
    <Footer />

    </>
    
    
  );
}

export default App;
